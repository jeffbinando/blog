<?php

/**
 * Class ffBreadcrumbsCollection
 *
 * collection of breadcrumbs, implements iterator, so could be threaded as array, contains ffOneBreadcrumb
 */
class ffBreadcrumbsCollection extends ffCollection {

}